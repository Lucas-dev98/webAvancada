const express = require("express");
const bodyParser = require("body-parser");

const mongoose = require("mongoose");  // Importando o Mongoose
const appRoutes = require('./routes/app');


var path = require('path');

const app = express();

const hbs = require('hbs');

mongoose.connect('mongodb://127.0.0.1:27017/node-mongoose-ativextra')
  .then(() => {
    console.log('Conexão com o MongoDB estabelecido com sucesso.')
  })
  .catch((error) => {
    console.error('Erro na conexão com o MongoDB:', error);
  });
  
hbs.registerHelper('dateFormat', require('handlebars-dateformat'));

app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'hbs');

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));

app.use(express.static(path.join(__dirname, 'public')));

// Configuração do CORS 
app.use((req, res, next) => {
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
  res.setHeader("Access-Control-Allow-Methods", "GET, POST, PATCH, DELETE, OPTIONS");
  next();
});

app.use('/', appRoutes);

module.exports = app;
